public class Example {

  /**
   * @param args
   */
  public static void main(String[] args) {

    String x = args[0];
    NOP();
    NOP(x);
    NOP("Lala");
    int y = getSecureRandom();
    NOP(y);
    boolean flag = true;
    if (flag)
      x = sanitize(x);

    consume(x);

  }

  public static String sanitize(String s) {
    return s;
  }

  public static void consume(String input) {
    String local = input;
    evil();

  }

  public static void NOP(int i) {

  }

  public static void NOP(String s) {

  }

  public static void NOP() {
    int r = getSecureRandom();
  }

  public static int getSecureRandom() {
    return 4;
  }

  private static void evil() {

  }

}
